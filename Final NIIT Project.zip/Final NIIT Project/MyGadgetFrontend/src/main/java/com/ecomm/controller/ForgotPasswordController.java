package com.ecomm.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
public class ForgotPasswordController 
{
	@RequestMapping("/forgotpassword")
	public String showForgotPage()
	{
		System.out.println("==== Forgot Password Page Created ====");
		return "ForgotPassword";
	}
	
}
