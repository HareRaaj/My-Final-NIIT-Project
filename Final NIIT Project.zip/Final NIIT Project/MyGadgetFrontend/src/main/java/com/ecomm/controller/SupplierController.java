package com.ecomm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ecomm.dao.SupplierDAO;
import com.ecomm.entity.Product;
import com.ecomm.entity.Supplier;

@Controller
public class SupplierController 
{
	@Autowired
	SupplierDAO supplierDAO;
	
	@RequestMapping("/supplier")
	public String showSupplierPage(Model m)
	{
		List<Supplier> supplierList=supplierDAO.getSuppliers();
		m.addAttribute("supplierList", supplierList);
		
		System.out.println("=====Supplier page creation====");
		return "Supplier";
	}
	
	@RequestMapping(value="/insertSupplier", method=RequestMethod.POST)
	public String insertSupplier(@RequestParam("supId")int supId,@RequestParam("supName")String supName,@RequestParam("supDesc")String supDesc,@RequestParam("supLoc")String supLoc,Model m)
	{
		System.out.println("Supplier Id:"+supId);
		System.out.println("Supplier Name:"+supName);
		System.out.println("Supplier Desc:"+supDesc);
		System.out.println("Supplier Location:"+supLoc);
		
		Supplier supplier=new Supplier();
		supplier.setSupplierId(supId);
		supplier.setSupplierName(supName);
		supplier.setSupplierDesc(supDesc);
		supplier.setSupplierLocation(supLoc);
		
		supplierDAO.addSupplier(supplier);
		
		System.out.println("Supplier object created");
		List<Supplier> supplierList=supplierDAO.getSuppliers();
		m.addAttribute("supplierList", supplierList);
		
		return "Supplier";		
	}
	
	@RequestMapping("/deleteSupplier/{supplierId}")
	public String deleteProduct(@PathVariable("supplierId")int supplierId,Model m)
	{
		Supplier supplier=supplierDAO.getSupplier(supplierId);
		supplierDAO.deleteSupplier(supplier);
		
		List<Supplier> supplierList=supplierDAO.getSuppliers();
		m.addAttribute("supplierList", supplierList);
		
		return "Supplier";	
	}
	
	@RequestMapping("/editSupplier/{supplierId}")
	public String editProduct(@PathVariable("supplierId")int supplierId,Model m)
	{
		Supplier supplier=supplierDAO.getSupplier(supplierId);
		m.addAttribute("supplier", supplier);
		
		return "UpdateSupplier";
	}
	
	@RequestMapping(value="/updateSupplier", method=RequestMethod.POST)
	public String updateProduct(@RequestParam("supId")int supId,@RequestParam("supName")String supName,@RequestParam("supDesc")String supDesc,@RequestParam("supLoc")String supLoc,Model m)
	{
		System.out.println("Supplier Id:"+supId);
		System.out.println("Supplier Name:"+supName);
		System.out.println("Supplier Desc:"+supDesc);
		System.out.println("Supplier Location:"+supLoc);
		
		Supplier supplier=new Supplier();
		supplier.setSupplierId(supId);
		supplier.setSupplierName(supName);
		supplier.setSupplierDesc(supDesc);
		supplier.setSupplierLocation(supLoc);
		
		supplierDAO.updateSupplier(supplier);
		
		List<Supplier> supplierList=supplierDAO.getSuppliers();
		m.addAttribute("supplierList", supplierList);
		
		return "Supplier";			
	}
}
