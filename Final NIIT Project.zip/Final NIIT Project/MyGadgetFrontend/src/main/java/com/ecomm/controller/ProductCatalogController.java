package com.ecomm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ecomm.dao.CategoryDAO;
import com.ecomm.entity.Category;

@Controller
public class ProductCatalogController 
{
	@Autowired
	CategoryDAO categoryDAO;
	
	@RequestMapping("/productcatalog")
	public String showCatalogPage(Model m)
	{
		List<Category> categoryList=categoryDAO.getCategories();
		m.addAttribute("categoryList", categoryList);
		
		System.out.println("==== Product Catalog Page Created ====");
		return "ProductCatalog";
	}
}
