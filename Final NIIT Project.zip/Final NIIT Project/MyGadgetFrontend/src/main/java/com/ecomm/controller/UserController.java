package com.ecomm.controller;

import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ecomm.dao.UserDAO;
import com.ecomm.entity.UserDetail;

@Controller
public class UserController 
{
	@Autowired
	UserDAO userDAO;
	
	@RequestMapping(value="/login_success", method=RequestMethod.POST)
	
	public  String loginsuccess(HttpSession session)
	{
		String page="";
		
		System.out.println("I am in Login Success");
		
		SecurityContext sContext=SecurityContextHolder.getContext();
		Authentication authentication=sContext.getAuthentication();
		
		String username=authentication.getName();
		session.setAttribute("username", username);
		
		Collection<GrantedAuthority> roles=(Collection<GrantedAuthority>)authentication.getAuthorities();
		
		for(GrantedAuthority role:roles)
		{
			session.setAttribute("role", role.getAuthority());
			
			if(role.getAuthority().equals("USER ADMIN"))
				page="AdminHome";
			else
				page="UserHome";
		}
		return page;
	}
	
	@RequestMapping("/signup")
	public String showSignUpPage(Model m)
	{
		UserDetail userDetail=new UserDetail();
		m.addAttribute("customer", userDetail);
		return "Signup";
	}
	
	@RequestMapping(value="/register", method=RequestMethod.POST)
	public String signUp(@ModelAttribute("customer")UserDetail userDetail,Model m)
	{
		/*System.out.println("Customer User Name:"+userDetail.getUsername());
		System.out.println("Customer Name:"+userDetail.getCustomerName());
		System.out.println("Customer Address:"+userDetail.getAddress());*/
		
		userDetail.setEnabled(true);
		userDetail.setRole("ROLE USER");
		
		userDAO.registeruser(userDetail);
		
		m.addAttribute("customer", userDetail);
		return "ConfirmSignUp";
	}
	
	@RequestMapping(value="/logout", method=RequestMethod.GET)  
    public String logoutPage(HttpServletRequest request, HttpServletResponse response) {  
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();  
        if (auth != null)
        {      
           new SecurityContextLogoutHandler().logout(request, response, auth);  
        }  
         return "Logout";  
     }  
}
