package com.ecomm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ecomm.dao.ProductDAO;
import com.ecomm.entity.Product;

@Controller
public class ProductController 
{
	@Autowired
	ProductDAO productDAO;
	
	@RequestMapping("/product")
	public String showProductPage(Model m)
	{
		List<Product> productList=productDAO.getProducts();
		m.addAttribute("productList", productList);
		
		System.out.println("=====Product page creation====");
		return "Product";
	}
	
	@RequestMapping(value="/insertProduct", method=RequestMethod.POST)
	public String insertProduct(@RequestParam("prodId")int prodId,@RequestParam("prodName")String prodName,@RequestParam("prodDesc")String prodDesc,@RequestParam("suppName")String suppName,Model m)
	{
		System.out.println("Product Id:"+prodId);
		System.out.println("Product Name:"+prodName);
		System.out.println("Product Desc:"+prodDesc);
		System.out.println("Supplier Name:"+suppName);
		
		Product product=new Product();
		product.setProductId(prodId);
		product.setProductName(prodName);
		product.setProductDesc(prodDesc);
		product.setSupName(suppName);
		
		productDAO.addProduct(product);
		
		System.out.println("Product object created");
		List<Product> productList=productDAO.getProducts();
		m.addAttribute("productList", productList);
		return "Product";		
	}
	
	@RequestMapping("/deleteProduct/{productId}")
	public String deleteProduct(@PathVariable("productId")int productId,Model m)
	{
		Product product=productDAO.getProduct(productId);
		productDAO.deleteProduct(product);
		
		List<Product> productList=productDAO.getProducts();
		m.addAttribute("productList", productList);
		return "Product";	
	}
	
	@RequestMapping("/editProduct/{productId}")
	public String editProduct(@PathVariable("productId")int productId,Model m)
	{
		Product product=productDAO.getProduct(productId);
		m.addAttribute("product", product);
		
		return "UpdateProduct";
	}
	
	@RequestMapping(value="/updateProduct", method=RequestMethod.POST)
	public String updateProduct(@RequestParam("prodId")int prodId,@RequestParam("prodName")String prodName,@RequestParam("prodDesc")String prodDesc,@RequestParam("suppName")String suppName,Model m)
	{
		System.out.println("Product Id:"+prodId);
		System.out.println("Product Name:"+prodName);
		System.out.println("Product Desc:"+prodDesc);
		System.out.println("Supplier Name:"+suppName);
		
		Product product=new Product();
		product.setProductId(prodId);
		product.setProductName(prodName);
		product.setProductDesc(prodDesc);
		product.setSupName(suppName);
		
		productDAO.updateProduct(product);
		
		List<Product> productList=productDAO.getProducts();
		m.addAttribute("productList", productList);
		
		return "Product";		
	}
	
}
