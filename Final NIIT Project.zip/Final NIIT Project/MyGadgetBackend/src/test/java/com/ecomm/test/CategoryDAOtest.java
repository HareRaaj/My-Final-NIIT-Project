package com.ecomm.test;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.ecomm.dao.CategoryDAO;
import com.ecomm.entity.Category;

public class CategoryDAOtest 
{
	static CategoryDAO categoryDAO;
	
	@BeforeClass
	public static void initialize()
	{
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.ecomm");
		context.refresh();
		
		categoryDAO=(CategoryDAO)context.getBean("categoryDAO");
	}
	
	
	@Test
	public void addCategorytest()
	{
		Category category=new Category();
		category.setCategoryId(1005);
		category.setCategoryName("Google pixel");
		category.setCategoryDesc("Google pixel with latest android version");
		
		assertTrue("Problem occured while adding Category:",categoryDAO.addCategory(category));
	}
	
	@Ignore
	@Test
	public void updateCategoryTest()
	{
		Category category=categoryDAO.getCategory(1004);
		category.setCategoryName("Pixel");
		category.setCategoryDesc("All new apple with night mode camera");
		
		assertTrue("Problem occured while updating Category:",categoryDAO.updateCategory(category));
	}
	
	@Ignore
	@Test
	public void deleteCategoryTest()
	{
		Category category=categoryDAO.getCategory(1003);
		assertTrue("Problem occured while deleting category:",categoryDAO.deleteCategory(category));
	}
	
	@Ignore
	@Test
	public void getCategoriesTest()
	{
		List<Category> categoryList=categoryDAO.getCategories();
		
		assertTrue("Problem occured while retreiving:",categoryList.size()>0);
		
		for(Category category:categoryList)
		{
			System.out.println("Category Id:"+category.getCategoryId());
			System.out.println("Category Name:"+category.getCategoryName());
		}
	}
}
