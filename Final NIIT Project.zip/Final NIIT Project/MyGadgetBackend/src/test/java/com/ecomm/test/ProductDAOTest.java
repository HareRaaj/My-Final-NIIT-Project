package com.ecomm.test;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.ecomm.dao.ProductDAO;
import com.ecomm.entity.Product;

public class ProductDAOTest 
{
	static ProductDAO productDAO;
	
	@BeforeClass
	public static void initialize()
	{
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.ecomm");
		context.refresh();
		
		productDAO=(ProductDAO)context.getBean("productDAO");
	}
	
	@Ignore
	@Test
	public void addProducttest()
	{
		Product product=new Product();
		product.setProductId(103);
		product.setProductName("Mobile");
		product.setProductDesc("Handheld device used for communication");
		product.setSupName("Apple");
		
		assertTrue("Problem occured while adding Product:",productDAO.addProduct(product));
	}
	
	@Ignore
	@Test
	public void updateProductTest()
	{
		Product product=productDAO.getProduct(102);
		product.setProductName("Earphone");
		product.setProductDesc("Bluetooth earphones supported for mobile use");
		product.setSupName("Boat");
		
		assertTrue("Problem occured while updating Product:",productDAO.updateProduct(product));
	}
	
	@Ignore
	@Test
	public void deleteProductTest()
	{
		Product product=productDAO.getProduct(001);
		assertTrue("Problem occured while deleting product:",productDAO.deleteProduct(product));
	}
	
	@Test
	public void getProductTest()
	{
		List<Product> productList=productDAO.getProducts();
		
		assertTrue("Problem occured while retreiving:",productList.size()>0);
		
		for(Product product:productList)
		{
			System.out.println("Product Id:"+product.getProductId());
			System.out.println("Product Name:"+product.getProductName());
		}
		
	}
	
}
