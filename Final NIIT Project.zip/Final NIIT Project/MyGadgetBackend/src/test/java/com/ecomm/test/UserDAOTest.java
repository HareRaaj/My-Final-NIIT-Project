package com.ecomm.test;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.ecomm.dao.CategoryDAO;
import com.ecomm.dao.UserDAO;
import com.ecomm.entity.Category;
import com.ecomm.entity.UserDetail;

public class UserDAOTest 
{
	static UserDAO userDAO;
	
	@BeforeClass
	public static void initialize()
	{
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.ecomm");
		context.refresh();
		
		userDAO=(UserDAO)context.getBean("userDAO");
	}
	
	@Test
	public void userDAOtest()
	{
		UserDetail user=new UserDetail();
		user.setUsername("Stark");
		user.setPassword2("1234");
		user.setEmailid("stark@gmail.com");
		user.setCustomerName("Tony Stark");
		user.setMobileNo("7384329224");
		user.setEnabled(true);
		user.setAddress("Florida");
		user.setRole("ROLE USER");
		
		assertTrue("Problem occured while inserting", userDAO.registeruser(user));
	}
}
