package com.ecomm.dao;

import com.ecomm.entity.UserDetail;

public interface UserDAO 
{
	public boolean registeruser(UserDetail user);
	public boolean updateuser(UserDetail user);
	public UserDetail getUser(String username);
}
